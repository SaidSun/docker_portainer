﻿# Docker Desktop, Portainer и мониторинговый Stack

Автор: Сунгатуллин Саид Рустамович
Группа: М3О-226СВ-25
МАИ, Институт №3, кафедра №307

## Состав

- `01_nginx_portainer_report.pdf` — отчёт по Portainer и nginx.
- `01_nginx_portainer_report.docx` — редактируемая версия первого отчёта.
- `02_monitoring_stack_report.pdf` — отчёт по Grafana Alloy, VictoriaMetrics и Grafana OSS.
- `stack/` — Docker Compose, конфигурация Alloy и provisioning Grafana.
- `smartctl_exporter_build/` — Dockerfile и исходный бинарный релиз exporter.
- `screenshots/` — доказательства работы сервисов.
- `image-manifest.txt` — версии, ID и digest образов.
- `email_draft.txt` — текст сопроводительного письма.

## Запуск

1. Создать сеть: `docker network create observability_net`.
2. В каталоге `stack` выполнить `docker compose up -d`.
3. Отдельно запустить smartctl-exporter согласно команде из отчёта или собрать локальный образ из `smartctl_exporter_build`.
4. Проверить: Grafana `http://localhost:3000`, VictoriaMetrics `http://localhost:8428/vmui`, Alloy `http://localhost:12345`.

## Фактическая проверка

Подтверждены HTTP 200 для exporter, VictoriaMetrics, Alloy и Grafana. Запрос `up` в VictoriaMetrics вернул значение 1, `smartctl_devices` — 5. Температурная метрика `smartctl_device_temperature` в Docker Desktop не появилась; это ограничение доступа Linux VM к физическим дискам, а не подставленные тестовые данные.

## Безопасность

Порты Stack привязаны к `127.0.0.1`. Пароли в учебной конфигурации предназначены только для локальной лаборатории; перед публикацией сервисов необходимо заменить их и включить штатную защиту.
